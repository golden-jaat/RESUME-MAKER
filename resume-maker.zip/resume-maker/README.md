# Resume maker

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jatinjaat/pen/vEBMdZv](https://codepen.io/Jatinjaat/pen/vEBMdZv).

